<?php
/*
Template Name: Links
*/
?>

<?php get_header(); ?>

<div id="wrapper">
<div id="content">

<h2>Links:</h2>
<ul>
<?php get_links_list(); ?>
</ul>

</div>	
<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
