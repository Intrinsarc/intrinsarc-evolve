<?php get_header(); ?>
<?php get_sidebar(); ?>

<div class="content">
		
		<h2>Error 404 - Page not Found</h2>
        <p>We are sorry but the page you are looking for does not exist.<br/>
        You might want to do a quick search:<br/>
        <?php
get_search_form();
?>
        </p>
			
	

</div><!-- end content-->
<?php get_footer(); ?>