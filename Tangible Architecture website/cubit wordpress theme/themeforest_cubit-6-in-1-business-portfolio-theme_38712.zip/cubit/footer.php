<?php global $kriesi_options;?>   
    </div><!-- end main-->
    <div id="footer">
    &copy; Copyright Cubit - Design by <a href="http://www.kriesi.at/">Kriesi</a> - Fill In your own Copyright info here and remove mine after purchasing ;)
    </div>
</div><!-- end top-->
		<?php wp_footer(); ?>
<?php echo $kriesi_options['google_analaytics']; ?>      
</body>
</html>
