package com.acme.homemonitoring;

import java.util.ArrayList;
import java.util.List;

public class IntruderDetector
{
	private List<Room> rooms = new ArrayList<Room>();
	
	public void addRoom(Room room)
	{
		rooms.add(room);
	}
	
	public void intruderDetected(String location)
	{
		System.out.println("!! intruder detected in location " + location);
		ReallyLoudSiren.getInstance().soundSiren();
	}
	
	public void reset()
	{
		for (Room room : rooms)
			room.reset();
	}

	public void report()
	{
		// ask each room and the siren to report
		System.out.println("Report on security\n------------------\n");
		for (Room room : rooms)
		{
			room.report();
			System.out.println();
		}
		ReallyLoudSiren.getInstance().report();
	}
}
