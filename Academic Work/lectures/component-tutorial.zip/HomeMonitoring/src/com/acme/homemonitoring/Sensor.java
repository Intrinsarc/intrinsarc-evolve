package com.acme.homemonitoring;

public class Sensor
{
	private Room room;
	private Light light;
	
	public Sensor(Room room, Light light)
	{
		this.room = room;
	}
	
	/**
	 * this would be triggered by the physical sensor indicating it had been tripped by an intruder
	 */
	public void sensorTripped()
	{
		// notify the room and turn on the light		
		light.turnOn();
		room.sensorTripped();
	}

	public void reset()
	{
		System.out.println("!! sensor reset");
	}

	public void report()
	{
		System.out.println("  Sensor");
	}
}
