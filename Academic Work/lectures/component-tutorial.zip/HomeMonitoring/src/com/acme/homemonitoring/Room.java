package com.acme.homemonitoring;

public class Room
{
	private IntruderDetector detector;
	private String name;
	private int threshold;
	
	private Light light;
	private Sensor sensor;
	
	private int trips;
	
	public Room(IntruderDetector detector, String name, int threshold)
	{
		this.detector = detector;
		this.name = name;
		this.threshold = threshold;
		light = new Light(name);
		sensor = new Sensor(this, light);
	}

	public void sensorTripped()
	{
		// if we have had N trips, notify the detector
		if (++trips == threshold)
			detector.intruderDetected("Intruder detected in " + name);
	}
	
	public void reset()
	{
		light.turnOff();
		sensor.reset();
		trips = 0;
	}

	public void report()
	{
		System.out.println("Room: " + name);
		light.report();
		sensor.report();
	}
}
