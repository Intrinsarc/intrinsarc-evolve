package com.acme.homemonitoring;

/**
 * exercise 1: find a way to wire up a mock Siren class
 * exercise 2: find a way to wire up mock Sensor / Light classes
 */

public class Main
{
	public static void main(String args[])
	{
		IntruderDetector detector = new IntruderDetector();
		detector.addRoom(new Room(detector, "Lounge room", 3));
		detector.addRoom(new Room(detector, "Study", 1));
		detector.report();
	}	
}
