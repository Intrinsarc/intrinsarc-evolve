package com.acme.homemonitoring;

/**
 * a singleton siren class
 */
public class ReallyLoudSiren
{
	private static ReallyLoudSiren instance = new ReallyLoudSiren();
	
	private ReallyLoudSiren() {}
	
	public static ReallyLoudSiren getInstance()
	{
		return instance;
	}
	
	public void soundSiren()
	{
		System.out.println("!! really load siren turned on for 10 seconds");
	}

	public void report()
	{
		System.out.println("ReallyLoadSiren");
	}
}
