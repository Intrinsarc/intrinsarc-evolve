package com.acme.homemonitoring;

public class Light
{
	private String name;
	
	public Light(String name)
	{
		this.name = name;
	}
	
	public void turnOn()
	{
		System.out.println("!! turning on light " + name);
	}
	
	public void turnOff()
	{
		System.out.println("!! turning off light " + name);
	}

	public void report()
	{
		System.out.println("  Light");
	}
}
