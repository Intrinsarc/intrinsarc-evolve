package sweng_smartcard;

import company.CompanyCardholder;

import application.Application;
import applicationdeliverychannel.OnlineDeliveryChannel;
import request.ApplicationRequest;
import smartcard.SmartCard;
import cardholder.Cardholder;

public class Test
{
	public static void main(String args[])
	{
		// make the online delivery channel
		OnlineDeliveryChannel deliveryChannel = new OnlineDeliveryChannel();
		
		// make a cardholder and a card
		Cardholder andrew = new Cardholder("Andrew", deliveryChannel);
		SmartCard card = new SmartCard(andrew, "4332312354");
		andrew.addCard(card);
		
		// create an application
		Application loyaltyApp = new Application("Loyalty Application");
		
		// build the application and deliver it
		ApplicationRequest request = new ApplicationRequest(andrew, loyaltyApp, card.getCardNumber());
		request.buildApplicationAndDeliverIt();
		
//		// for objective (2), we would also like to run
//		// make a cardholder and a card
//		CompanyCardholder consolidated = new CompanyCardholder("Consolidated Holdings plc", deliveryChannel);
//		SmartCard companyCard = new SmartCard(consolidated, "4666312354");
//		consolidated.addCard(companyCard);
//		
//		// build the application and deliver it
//		ApplicationRequest companyRequest = new ApplicationRequest(consolidated, loyaltyApp, companyCard.getCardNumber());
//		companyRequest.buildApplicationAndDeliverIt();		
	}
	
	
}
