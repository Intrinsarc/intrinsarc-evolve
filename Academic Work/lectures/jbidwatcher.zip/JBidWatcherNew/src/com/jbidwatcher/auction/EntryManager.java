package com.jbidwatcher.auction;
/*
 * Copyright (c) 2000-2007, CyberFOX Software, Inc. All Rights Reserved.
 *
 * Developed by mrs (Morgan Schweers)
 */

public interface EntryManager {
  public abstract void addEntry(AuctionEntry ae);
  public abstract void delEntry(AuctionEntry ae);
}
