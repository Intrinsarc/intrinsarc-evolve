require 'builtin/javasupport/core_ext/module'
require 'builtin/javasupport/core_ext/object'
require 'builtin/javasupport/core_ext/kernel'