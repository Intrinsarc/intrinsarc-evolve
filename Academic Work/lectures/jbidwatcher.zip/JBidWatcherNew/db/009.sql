CREATE INDEX IDX_Auction_Title ON auctions(title)
