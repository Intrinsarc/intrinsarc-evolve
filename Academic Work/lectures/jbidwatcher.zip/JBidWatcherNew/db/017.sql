ALTER TABLE entries ADD COLUMN winning smallint default NULL
