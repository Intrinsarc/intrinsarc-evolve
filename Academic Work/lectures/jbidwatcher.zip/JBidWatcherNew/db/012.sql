ALTER TABLE entries ADD COLUMN deleted smallint
