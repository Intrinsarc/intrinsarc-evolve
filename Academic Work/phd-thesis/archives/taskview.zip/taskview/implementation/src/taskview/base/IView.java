package taskview.base;

public interface IView
{
  void display();
}
