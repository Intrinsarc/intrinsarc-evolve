package taskview.base;

public interface IGrid
{
  void display(String title);
}
