package taskview.base;

public interface IGridDataProvider
{
	//@todo add in the methods
}
