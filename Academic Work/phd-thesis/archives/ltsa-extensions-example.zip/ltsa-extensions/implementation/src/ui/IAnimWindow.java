package ui;

import java.awt.*;

import lts.*;

public interface IAnimWindow
{
	void activate(RunMenu r, boolean selected, boolean replay, Point point);
}
