package actions;


public interface INameListener
{
	void haveNewNames();
}
