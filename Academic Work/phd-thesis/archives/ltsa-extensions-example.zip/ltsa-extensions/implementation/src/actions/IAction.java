package actions;

public interface IAction
{
	public boolean doAction();
	public String getIcon();
	public String getName();
}
