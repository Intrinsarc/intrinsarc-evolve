package lts;

public interface EventClient {
	public void ltsAction(LTSEvent e);
}