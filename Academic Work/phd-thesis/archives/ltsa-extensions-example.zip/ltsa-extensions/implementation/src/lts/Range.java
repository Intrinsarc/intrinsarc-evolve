package lts;

import java.util.*;

/* -----------------------------------------------------------------------*/

class Range extends Declaration {
	static Hashtable ranges;
	Stack low;
	Stack high;
}