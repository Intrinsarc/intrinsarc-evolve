package lts;

public interface IAnimator extends Animator, Automata
{
}
