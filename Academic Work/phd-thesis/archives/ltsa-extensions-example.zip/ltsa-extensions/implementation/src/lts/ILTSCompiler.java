package lts;

public interface ILTSCompiler
{
	//@todo add in the methods
}
