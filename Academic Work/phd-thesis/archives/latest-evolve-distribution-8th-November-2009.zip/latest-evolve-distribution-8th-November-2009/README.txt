
Running Evolve
--------------

To run Evolve, either double-click on evolve.jar in a file manager, or execute it using java:

  java -jar evolve.jar

You must have at least Java 1.5 and above.  If any any doubt about the version, type:

  java -version

Any problems, feel free to contact me at andrew@tanarc.com

Cheers,
Andrew McVeigh
8th July 2009 
