package custom;

public interface AnimationControl {
    public void signalControl(String name);
    public void clearControl(String name);
}
