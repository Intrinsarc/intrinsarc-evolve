package custom;

public interface AnimationMessage {
    public void traceMsg(String msg);
    public void debugMsg(String msg);
}
