package custom;

public interface AnimationAction {
    public void action();
}
