package lts;

public interface LTSOutput {

    public void out ( String str );

	public void outln ( String str );

	public void clearOutput ();
	
}