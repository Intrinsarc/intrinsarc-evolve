package lts;

public interface LTSInput {
      public char nextChar ();
	public char backChar ();
	public int getMarker ();
}