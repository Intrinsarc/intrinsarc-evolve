package markerview;

public interface IView
{
  void display();
}
