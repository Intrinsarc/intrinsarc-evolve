package markerview;

public interface IGridColumn
{
  String getName();
}
