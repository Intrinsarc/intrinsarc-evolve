package markerview;

public interface IGrid
{
  void display(String title);
}
