package markerview;

public interface IGridDataEntry
{
	//@todo add in the methods
}
