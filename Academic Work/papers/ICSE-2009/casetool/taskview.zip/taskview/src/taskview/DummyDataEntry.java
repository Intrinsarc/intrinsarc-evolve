package taskview;

import com.hopstepjump.backbone.api.*;

public class DummyDataEntry
{
// start generated code
	private markerview.IGridDataEntry g_IGridDataEntryProvided = new IGridDataEntryGImpl();
// end generated code


	private class IGridDataEntryGImpl implements markerview.IGridDataEntry
	{
		//@todo add interface methods
	}

}
