package com.intrinsarc.states;

import com.intrinsarc.backbone.runtime.api.*;

public interface IRentalEvent
// start generated code
	extends com.intrinsarc.base.IRenterDetails, IEvent
{
// end generated code
	void rent();
	void returnRental();
}
