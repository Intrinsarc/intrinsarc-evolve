package com.intrinsarc.base;


public class RenterDetails
// start generated code
	// main port
 implements com.intrinsarc.base.IRenterDetails
{
	// attributes
	private String renterName = "";

	// attribute setters and getters
	public String getRenterName() { return renterName; }
	public void setRenterName(String renterName) { this.renterName = renterName;}

// end generated code
}
