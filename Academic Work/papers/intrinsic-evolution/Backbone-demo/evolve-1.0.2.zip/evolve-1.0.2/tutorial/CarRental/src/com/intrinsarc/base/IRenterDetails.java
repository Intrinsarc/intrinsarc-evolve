package com.intrinsarc.base;

public interface IRenterDetails
// start generated code
{
// end generated code
	void setRenterName(String renterName);
	String getRenterName();
}
